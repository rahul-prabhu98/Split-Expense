package edu.darshandedhia.info6250.exception;

public class DatabaseException extends Exception{
	public DatabaseException(String message) {
		super(message);
	}
}
