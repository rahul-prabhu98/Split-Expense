package edu.darshandedhia.info6250.constants;

public class Status {
	public static String success = "SUCCESS";
	public static String error = "ERROR";
	public static String failure = "FAILURE";
}
