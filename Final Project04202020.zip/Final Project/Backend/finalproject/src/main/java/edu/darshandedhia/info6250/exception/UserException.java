package edu.darshandedhia.info6250.exception;

public class UserException extends Exception{
	
	public UserException(String message) {
		super(message);
	}
	
}
