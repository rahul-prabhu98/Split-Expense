import { Pipe, PipeTransform } from '@angular/core';
import {UserServiceService} from '../services/user-service.service';

@Pipe({
  name: 'user'
})
export class UserPipe implements PipeTransform {

  constructor(private userService: UserServiceService) {}

  transform(value: any, ...args: any[]): any {
    const user = this.userService.getterFriendsList().find((u) => u.userId = value);
    return user.name;
  }

}
