import { YourSharePipe } from './your-share.pipe';

describe('YourSharePipe', () => {
  it('create an instance', () => {
    const pipe = new YourSharePipe();
    expect(pipe).toBeTruthy();
  });
});
