import { AbsolutePipe } from './absolute.pipe';

describe('AbsolutePipe', () => {
  it('create an instance', () => {
    const pipe = new AbsolutePipe();
    expect(pipe).toBeTruthy();
  });
});
