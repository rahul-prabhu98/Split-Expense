export class Report {
  public id: number;
  public user: number;
  public paid: number;
  public ownShare: number;
  public percentage: number;
  public transaction: number;
}
